# Maze Pro  (`com.maze.bdcreator`)

3D mobile maze game — Kotlin UI + C/C++ (NDK) game engine + OpenGL ES 3.0.

## কিভাবে চালাবে
1. Android Studio (Ladybug / Meerkat বা নতুন) দিয়ে **MazeBDCreator** ফোল্ডারটা Open করো।
2. প্রথমবার Gradle sync হবে — Android Studio নিজে Gradle 8.9 ডাউনলোড করবে।
3. **SDK Manager → SDK Tools** থেকে এই দুটো install করা থাকতে হবে:
   - NDK (Side by side)
   - CMake 3.22.1
4. ফোন USB দিয়ে লাগাও (বা emulator) → ▶ Run।
5. APK বানাতে: **Build → Build Bundle(s) / APK(s) → Build APK(s)**

> যদি `gradlew` না থাকার কারণে সমস্যা হয়: Android Studio-র Terminal-এ `gradle wrapper --gradle-version 8.9` চালাও,
> অথবা Settings → Build Tools → Gradle থেকে Gradle JDK 17+ সিলেক্ট করো।

## গেম কিভাবে কাজ করে
- লেভেল শুরুতে পুরো maze **৫ সেকেন্ড** উপর থেকে দেখানো হয় (সবুজ ক্রিস্টাল = তোমার শুরু, লাল ক্রিস্টাল = বের হওয়ার জায়গা)।
- তারপর ক্যামেরা নিচে নেমে **first-person 3D** হয়ে যায়, এবার লাল ক্রিস্টালে পৌঁছাতে হবে।
- **বাম পাশে** আঙুল দিয়ে joystick = চলা, **ডান পাশে** ড্র্যাগ = ঘোরা।
- ৫০টা লেভেল, লেভেল বাড়লে maze বড় হয় (5×5 → 21×21)। প্রতি ১০ লেভেলে নতুন থিম
  (teal → hedge → desert → violet night → lava)।
- লেভেল শেষ করলে পরেরটা আনলক হয়, সেরা সময় সেভ থাকে।

## ফাইল স্ট্রাকচার
```
app/src/main/cpp/
  mazegen.c / .h     C   — maze generator (recursive backtracker) + BFS (exit সবচেয়ে দূরে)
  game.cpp / .h      C++ — game state, 5s preview, collision, win check
  renderer.cpp / .h  C++ — OpenGL ES 3.0 renderer (3D walls, fog, camera transition)
  mathutil.h         C++ — matrix math
  native-lib.cpp         — JNI bridge
  CMakeLists.txt
app/src/main/java/com/maze/bdcreator/
  MainActivity.kt    — menu + level select (50 levels)
  GameActivity.kt    — HUD, pause/win panel
  ControlsView.kt    — touch joystick + look
  NativeBridge.kt    — JNI declarations
  GameRenderer.kt    — GLSurfaceView renderer
  Progress.kt        — save progress
```

## নিজে বদলানোর জায়গা
| কি বদলাবে | কোথায় |
|---|---|
| Preview সময় (৫ সেকেন্ড) | `game.h` → `PREVIEW_SECONDS` |
| Maze সাইজ / কঠিনতা | `game.cpp` → `Game::sizeForLevel` |
| চলার গতি | `game.h` → `MOVE_SPEED` |
| থিম/রঙ | `renderer.cpp` → `kThemes` |
| Look sensitivity | `ControlsView.kt` → `0.006f` |
