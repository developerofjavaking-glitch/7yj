#include "game.h"

#include <algorithm>
#include <cmath>

extern "C" {
#include "mazegen.h"
}

static const float kPi = 3.14159265358979f;

int Game::sizeForLevel(int lv) {
    // level 1 -> 5x5 ... level 50 -> 21x21 (grows smoothly)
    int s = 5 + ((lv - 1) * 16) / 49;
    return std::min(s, 21);
}

void Game::startLevel(int lv) {
    std::lock_guard<std::mutex> lk(mtx);

    level = std::max(1, std::min(MAX_LEVEL, lv));
    size = sizeForLevel(level);
    cells.assign((size_t) size * size, 0x0F);

    // every level has its own fixed maze (same seed -> same maze)
    uint32_t seed = (uint32_t) level * 2654435761u + 0x1234567u;
    mz_generate(cells.data(), size, size, seed);

    // start in one of the 4 corners (rotates with the level), exit = farthest cell
    int corners[4] = {0, size - 1, size * size - 1, (size - 1) * size};
    startCell = corners[(level - 1) % 4];
    int dist = 0;
    exitCell = mz_farthest(cells.data(), size, size, startCell, &dist);

    buildWalls();

    startX = (float) (startCell % size + 0.5f) * CELL;
    startZ = (float) (startCell / size + 0.5f) * CELL;
    exitX = (float) (exitCell % size + 0.5f) * CELL;
    exitZ = (float) (exitCell / size + 0.5f) * CELL;
    px = startX;
    pz = startZ;

    // look down the first open corridor
    uint8_t c = cells[startCell];
    if (!(c & MZ_E)) yaw = kPi * 0.5f;
    else if (!(c & MZ_S)) yaw = kPi;
    else if (!(c & MZ_W)) yaw = -kPi * 0.5f;
    else yaw = 0.0f;

    moveX = moveY = lookAccum = 0.0f;
    previewLeft = PREVIEW_SECONDS;
    transT = 0.0f;
    elapsed = 0.0f;
    paused = false;
    state = ST_PREVIEW;
    ++version;
}

void Game::buildWalls() {
    walls.clear();
    const float S = CELL;
    const float h = WALL_HALF_T;
    const int n = size;

    // horizontal walls (run along x) on the row boundaries j = 0..n
    for (int j = 0; j <= n; ++j) {
        for (int i = 0; i < n; ++i) {
            bool present;
            if (j == 0) present = cells[(size_t) i] & MZ_N;
            else if (j == n) present = cells[(size_t) (n - 1) * n + i] & MZ_S;
            else present = cells[(size_t) j * n + i] & MZ_N;
            if (present) walls.push_back({i * S - h, j * S - h, (i + 1) * S + h, j * S + h});
        }
    }
    // vertical walls (run along z) on the column boundaries i = 0..n
    for (int i = 0; i <= n; ++i) {
        for (int j = 0; j < n; ++j) {
            bool present;
            if (i == 0) present = cells[(size_t) j * n] & MZ_W;
            else if (i == n) present = cells[(size_t) j * n + (n - 1)] & MZ_E;
            else present = cells[(size_t) j * n + i] & MZ_W;
            if (present) walls.push_back({i * S - h, j * S - h, i * S + h, (j + 1) * S + h});
        }
    }
}

void Game::update(float dt) {
    std::lock_guard<std::mutex> lk(mtx);
    if (paused || state == ST_IDLE) return;
    dt = std::min(dt, 0.05f);

    switch (state) {
        case ST_PREVIEW:
            lookAccum = 0.0f;
            previewLeft -= dt;
            if (previewLeft <= 0.0f) {
                previewLeft = 0.0f;
                state = ST_TRANSITION;
                transT = 0.0f;
            }
            break;
        case ST_TRANSITION:
            lookAccum = 0.0f;
            transT += dt / 1.2f;
            if (transT >= 1.0f) {
                transT = 1.0f;
                state = ST_PLAY;
                elapsed = 0.0f;
            }
            break;
        case ST_PLAY: {
            elapsed += dt;
            stepPlayer(dt);
            float dx = px - exitX, dz = pz - exitZ;
            if (dx * dx + dz * dz < 0.85f * 0.85f) {
                state = ST_WON;
                moveX = moveY = 0.0f;
            }
            break;
        }
        default:
            lookAccum = 0.0f;
            break;
    }
}

void Game::stepPlayer(float dt) {
    yaw += lookAccum;
    lookAccum = 0.0f;

    float mx = moveX, my = moveY;
    float len = std::sqrt(mx * mx + my * my);
    if (len > 1.0f) {
        mx /= len;
        my /= len;
    }
    const float dx = std::sin(yaw), dz = -std::cos(yaw);  // forward
    const float rx = std::cos(yaw), rz = std::sin(yaw);   // right
    px += (dx * my + rx * mx) * MOVE_SPEED * dt;
    pz += (dz * my + rz * mx) * MOVE_SPEED * dt;
    resolveCollisions();
}

void Game::resolveCollisions() {
    const float r = PLAYER_R;
    for (int pass = 0; pass < 2; ++pass) {
        for (const Rect &w : walls) {
            if (px < w.x0 - r || px > w.x1 + r || pz < w.z0 - r || pz > w.z1 + r) continue;
            float cx = std::max(w.x0, std::min(px, w.x1));
            float cz = std::max(w.z0, std::min(pz, w.z1));
            float dx = px - cx, dz = pz - cz;
            float d2 = dx * dx + dz * dz;
            if (d2 >= r * r) continue;
            if (d2 > 1e-8f) {
                float d = std::sqrt(d2);
                float k = (r - d) / d;
                px += dx * k;
                pz += dz * k;
            } else {
                // centre is inside the wall: push out through the nearest face
                float l = px - w.x0, rr = w.x1 - px, t = pz - w.z0, b = w.z1 - pz;
                float m = std::min(std::min(l, rr), std::min(t, b));
                if (m == l) px = w.x0 - r;
                else if (m == rr) px = w.x1 + r;
                else if (m == t) pz = w.z0 - r;
                else pz = w.z1 + r;
            }
        }
    }
}

void Game::setMove(float strafe, float forward) {
    std::lock_guard<std::mutex> lk(mtx);
    moveX = strafe;
    moveY = forward;
}

void Game::addLook(float dyaw) {
    std::lock_guard<std::mutex> lk(mtx);
    lookAccum += dyaw;
}

void Game::skipPreview() {
    std::lock_guard<std::mutex> lk(mtx);
    if (state == ST_PREVIEW) previewLeft = 0.0f;
}

void Game::setPaused(bool p) {
    std::lock_guard<std::mutex> lk(mtx);
    paused = p;
    if (p) moveX = moveY = 0.0f;
}

CamState Game::camState() {
    std::lock_guard<std::mutex> lk(mtx);
    CamState c;
    c.state = state;
    c.level = level;
    c.size = size;
    c.version = version;
    c.px = px;
    c.pz = pz;
    c.yaw = yaw;
    c.transT = transT;
    c.previewLeft = previewLeft;
    c.elapsed = elapsed;
    c.startX = startX;
    c.startZ = startZ;
    c.exitX = exitX;
    c.exitZ = exitZ;
    return c;
}

int Game::getState() {
    std::lock_guard<std::mutex> lk(mtx);
    return state;
}

float Game::getPreviewLeft() {
    std::lock_guard<std::mutex> lk(mtx);
    return previewLeft;
}

float Game::getElapsed() {
    std::lock_guard<std::mutex> lk(mtx);
    return elapsed;
}

int Game::getLevel() {
    std::lock_guard<std::mutex> lk(mtx);
    return level;
}
