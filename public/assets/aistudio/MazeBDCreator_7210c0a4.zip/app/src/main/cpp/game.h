#pragma once

#include <cstdint>
#include <mutex>
#include <vector>

enum GameState {
    ST_IDLE = 0,        // nothing loaded yet
    ST_PREVIEW = 1,     // whole maze shown from above (5 seconds)
    ST_TRANSITION = 2,  // camera dives into first-person view
    ST_PLAY = 3,        // player is walking
    ST_WON = 4          // reached the exit
};

struct Rect {
    float x0, z0, x1, z1;
};

struct CamState {
    int state;
    int level;
    int size;
    int version;
    float px, pz, yaw;
    float transT;
    float previewLeft;
    float elapsed;
    float startX, startZ;
    float exitX, exitZ;
};

class Game {
public:
    static constexpr int MAX_LEVEL = 50;
    static constexpr float CELL = 2.0f;          // world units per maze cell
    static constexpr float WALL_H = 1.8f;
    static constexpr float WALL_HALF_T = 0.15f;  // half wall thickness
    static constexpr float PLAYER_R = 0.30f;
    static constexpr float EYE_H = 0.95f;
    static constexpr float MOVE_SPEED = 3.2f;    // units / second
    static constexpr float PREVIEW_SECONDS = 5.0f;

    static int sizeForLevel(int level);

    // --- called from any thread (all lock internally) ---
    void startLevel(int level);
    void update(float dt);
    void setMove(float strafe, float forward);
    void addLook(float dyaw);
    void skipPreview();
    void setPaused(bool p);
    CamState camState();
    int getState();
    float getPreviewLeft();
    float getElapsed();
    int getLevel();

    // --- level data, guarded by `mtx` when read from the renderer ---
    std::mutex mtx;
    std::vector<uint8_t> cells;
    std::vector<Rect> walls;
    int level = 1;
    int size = 5;
    int version = 0;
    int startCell = 0;
    int exitCell = 0;

private:
    void buildWalls();
    void stepPlayer(float dt);
    void resolveCollisions();

    int state = ST_IDLE;
    bool paused = false;
    float px = 0, pz = 0, yaw = 0;
    float startX = 0, startZ = 0, exitX = 0, exitZ = 0;
    float moveX = 0, moveY = 0, lookAccum = 0;
    float transT = 0, previewLeft = 0, elapsed = 0;
};
