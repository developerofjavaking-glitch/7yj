#pragma once

#include <GLES3/gl3.h>

#include <chrono>
#include <vector>

#include "game.h"

class Renderer {
public:
    explicit Renderer(Game &game) : game_(game) {}

    void onSurfaceCreated();
    void onSurfaceChanged(int w, int h);
    void onDrawFrame();

private:
    bool buildProgram();
    void buildGem();
    void rebuildLevelMesh();

    Game &game_;

    GLuint prog_ = 0;
    GLint uVP_ = -1, uModel_ = -1, uCam_ = -1, uFogColor_ = -1, uFogDen_ = -1, uTint_ = -1,
            uEmis_ = -1;

    GLuint levelVao_ = 0, levelVbo_ = 0;
    int levelVerts_ = 0;
    GLuint gemVao_ = 0, gemVbo_ = 0;
    int gemVerts_ = 0;

    int width_ = 1, height_ = 1;
    int builtVersion_ = -1;
    float timeSec_ = 0.0f;
    bool haveLast_ = false;
    std::chrono::steady_clock::time_point last_;
};
