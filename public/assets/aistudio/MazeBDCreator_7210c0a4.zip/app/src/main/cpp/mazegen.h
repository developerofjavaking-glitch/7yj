/*
 * mazegen.h  -  Pure C maze generator (recursive backtracker) + BFS solver helper.
 *
 * A maze is stored as w*h bytes. Each byte holds the walls that are still
 * PRESENT around that cell (bit set = wall exists).
 */
#ifndef MAZEGEN_H
#define MAZEGEN_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MZ_N 1  /* wall on the north side (towards -z) */
#define MZ_E 2  /* wall on the east side  (towards +x) */
#define MZ_S 4  /* wall on the south side (towards +z) */
#define MZ_W 8  /* wall on the west side  (towards -x) */

/* xorshift32 PRNG. state must be non-zero. */
uint32_t mz_rng_next(uint32_t *state);

/* Fills cells[w*h] with a perfect maze (one unique path between any 2 cells). */
void mz_generate(uint8_t *cells, int w, int h, uint32_t seed);

/*
 * Returns the index of the cell that is farthest (in steps) from `start`.
 * If outDist != NULL it receives that distance.
 */
int mz_farthest(const uint8_t *cells, int w, int h, int start, int *outDist);

#ifdef __cplusplus
}
#endif

#endif /* MAZEGEN_H */
