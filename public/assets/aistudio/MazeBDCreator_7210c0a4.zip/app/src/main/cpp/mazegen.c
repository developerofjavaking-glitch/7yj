#include "mazegen.h"

#include <stdlib.h>

static const int kDx[4]  = { 0, 1, 0, -1 };
static const int kDy[4]  = { -1, 0, 1, 0 };
static const int kBit[4] = { MZ_N, MZ_E, MZ_S, MZ_W };
static const int kOpp[4] = { MZ_S, MZ_W, MZ_N, MZ_E };

uint32_t mz_rng_next(uint32_t *state) {
    uint32_t x = *state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return x;
}

void mz_generate(uint8_t *cells, int w, int h, uint32_t seed) {
    const int total = w * h;
    int *stack = (int *) malloc((size_t) total * sizeof(int));
    uint8_t *visited = (uint8_t *) calloc((size_t) total, 1);
    uint32_t rng = seed ? seed : 0x9E3779B9u;
    int sp = 0;
    int i;

    if (!stack || !visited) {
        free(stack);
        free(visited);
        return;
    }

    for (i = 0; i < total; ++i) cells[i] = MZ_N | MZ_E | MZ_S | MZ_W;

    /* warm up the generator so that small seeds are not predictable */
    for (i = 0; i < 8; ++i) mz_rng_next(&rng);

    stack[sp++] = 0;
    visited[0] = 1;

    while (sp > 0) {
        int cur = stack[sp - 1];
        int cx = cur % w;
        int cy = cur / w;
        int nbCell[4];
        int nbDir[4];
        int n = 0;
        int d;

        for (d = 0; d < 4; ++d) {
            int nx = cx + kDx[d];
            int ny = cy + kDy[d];
            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
            if (visited[ny * w + nx]) continue;
            nbCell[n] = ny * w + nx;
            nbDir[n] = d;
            ++n;
        }

        if (n == 0) {
            --sp;
            continue;
        }

        {
            int k = (int) (mz_rng_next(&rng) % (uint32_t) n);
            cells[cur] &= (uint8_t) ~kBit[nbDir[k]];
            cells[nbCell[k]] &= (uint8_t) ~kOpp[nbDir[k]];
            visited[nbCell[k]] = 1;
            stack[sp++] = nbCell[k];
        }
    }

    free(stack);
    free(visited);
}

int mz_farthest(const uint8_t *cells, int w, int h, int start, int *outDist) {
    const int total = w * h;
    int *dist = (int *) malloc((size_t) total * sizeof(int));
    int *queue = (int *) malloc((size_t) total * sizeof(int));
    int head = 0, tail = 0, best = start, i;

    if (!dist || !queue) {
        free(dist);
        free(queue);
        if (outDist) *outDist = 0;
        return start;
    }

    for (i = 0; i < total; ++i) dist[i] = -1;
    dist[start] = 0;
    queue[tail++] = start;

    while (head < tail) {
        int cur = queue[head++];
        int cx = cur % w;
        int cy = cur / w;
        int d;

        if (dist[cur] > dist[best]) best = cur;

        for (d = 0; d < 4; ++d) {
            int nx, ny, nb;
            if (cells[cur] & kBit[d]) continue; /* wall in the way */
            nx = cx + kDx[d];
            ny = cy + kDy[d];
            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
            nb = ny * w + nx;
            if (dist[nb] >= 0) continue;
            dist[nb] = dist[cur] + 1;
            queue[tail++] = nb;
        }
    }

    if (outDist) *outDist = dist[best];
    free(dist);
    free(queue);
    return best;
}
