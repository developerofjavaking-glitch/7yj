#pragma once

#include <cmath>

// Tiny column-major (OpenGL style) matrix helpers.
namespace mu {

struct V3 {
    float x, y, z;
};

inline V3 add(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline V3 sub(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline V3 mul(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 cross(V3 a, V3 b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
inline float length(V3 a) { return std::sqrt(dot(a, a)); }
inline V3 norm(V3 a) {
    float l = length(a);
    return l > 1e-8f ? mul(a, 1.0f / l) : V3{0, 1, 0};
}
inline V3 lerp(V3 a, V3 b, float t) { return add(mul(a, 1.0f - t), mul(b, t)); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }

inline void perspective(float *m, float fovy, float aspect, float zn, float zf) {
    float f = 1.0f / std::tan(fovy * 0.5f);
    for (int i = 0; i < 16; ++i) m[i] = 0.0f;
    m[0] = f / aspect;
    m[5] = f;
    m[10] = (zf + zn) / (zn - zf);
    m[11] = -1.0f;
    m[14] = 2.0f * zf * zn / (zn - zf);
}

inline void lookAt(float *m, V3 eye, V3 center, V3 up) {
    V3 f = norm(sub(center, eye));
    V3 s = cross(f, up);
    if (length(s) < 1e-4f) s = cross(f, V3{1, 0, 0});  // up was parallel to forward
    s = norm(s);
    V3 u = cross(s, f);
    m[0] = s.x;  m[4] = s.y;  m[8] = s.z;   m[12] = -dot(s, eye);
    m[1] = u.x;  m[5] = u.y;  m[9] = u.z;   m[13] = -dot(u, eye);
    m[2] = -f.x; m[6] = -f.y; m[10] = -f.z; m[14] = dot(f, eye);
    m[3] = 0;    m[7] = 0;    m[11] = 0;    m[15] = 1;
}

// out = a * b   (out must not alias a or b)
inline void mul(float *out, const float *a, const float *b) {
    for (int c = 0; c < 4; ++c) {
        for (int r = 0; r < 4; ++r) {
            float sum = 0.0f;
            for (int k = 0; k < 4; ++k) sum += a[k * 4 + r] * b[c * 4 + k];
            out[c * 4 + r] = sum;
        }
    }
}

inline void identity(float *m) {
    for (int i = 0; i < 16; ++i) m[i] = 0.0f;
    m[0] = m[5] = m[10] = m[15] = 1.0f;
}

// model = Translate(x,y,z) * RotateY(a) * Scale(sx,sy,sz)
inline void model(float *m, float x, float y, float z, float a, float sx, float sy, float sz) {
    float c = std::cos(a), s = std::sin(a);
    for (int i = 0; i < 16; ++i) m[i] = 0.0f;
    m[0] = c * sx;  m[2] = -s * sx;
    m[5] = sy;
    m[8] = s * sz;  m[10] = c * sz;
    m[12] = x;      m[13] = y;      m[14] = z;
    m[15] = 1.0f;
}

}  // namespace mu
