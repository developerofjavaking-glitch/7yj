#include <jni.h>

#include "game.h"
#include "renderer.h"

static Game g_game;
static Renderer g_renderer(g_game);

extern "C" {

// ---- GL thread -----------------------------------------------------------
JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeSurfaceCreated(JNIEnv *, jclass) {
    g_renderer.onSurfaceCreated();
}

JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeSurfaceChanged(JNIEnv *, jclass, jint w, jint h) {
    g_renderer.onSurfaceChanged(w, h);
}

JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeDrawFrame(JNIEnv *, jclass) {
    g_renderer.onDrawFrame();
}

// ---- UI thread -----------------------------------------------------------
JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeStartLevel(JNIEnv *, jclass, jint level) {
    g_game.startLevel(level);
}

JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeSetMove(JNIEnv *, jclass, jfloat x, jfloat y) {
    g_game.setMove(x, y);
}

JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeAddLook(JNIEnv *, jclass, jfloat dyaw) {
    g_game.addLook(dyaw);
}

JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeSkipPreview(JNIEnv *, jclass) {
    g_game.skipPreview();
}

JNIEXPORT void JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeSetPaused(JNIEnv *, jclass, jboolean paused) {
    g_game.setPaused(paused == JNI_TRUE);
}

JNIEXPORT jint JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeGetState(JNIEnv *, jclass) {
    return g_game.getState();
}

JNIEXPORT jfloat JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeGetPreviewLeft(JNIEnv *, jclass) {
    return g_game.getPreviewLeft();
}

JNIEXPORT jfloat JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeGetElapsed(JNIEnv *, jclass) {
    return g_game.getElapsed();
}

JNIEXPORT jint JNICALL
Java_com_maze_bdcreator_NativeBridge_nativeGetLevel(JNIEnv *, jclass) {
    return g_game.getLevel();
}

}  // extern "C"
