#include "renderer.h"

#include <algorithm>
#include <cmath>

#include "log.h"
#include "mathutil.h"

extern "C" {
#include "mazegen.h"
}

namespace {

// ---------------------------------------------------------------- themes
struct Theme {
    float side[3];
    float top[3];
    float floorA[3];
    float floorB[3];
    float sky[3];
    float fog;  // fog density used in first-person view
};

// A new look every 10 levels
const Theme kThemes[5] = {
        // 1-10  : teal glass
        {{0.20f, 0.78f, 0.76f}, {0.85f, 1.00f, 0.98f}, {0.12f, 0.45f, 0.50f},
         {0.10f, 0.40f, 0.45f}, {0.55f, 0.90f, 0.90f}, 0.075f},
        // 11-20 : green hedge
        {{0.30f, 0.62f, 0.12f}, {0.45f, 0.80f, 0.20f}, {0.80f, 0.74f, 0.55f},
         {0.74f, 0.68f, 0.50f}, {0.62f, 0.86f, 1.00f}, 0.070f},
        // 21-30 : desert stone
        {{0.60f, 0.45f, 0.28f}, {0.82f, 0.67f, 0.44f}, {0.90f, 0.85f, 0.70f},
         {0.85f, 0.80f, 0.64f}, {0.95f, 0.88f, 0.72f}, 0.075f},
        // 31-40 : violet night
        {{0.45f, 0.25f, 0.75f}, {0.70f, 0.55f, 0.95f}, {0.16f, 0.11f, 0.28f},
         {0.20f, 0.14f, 0.33f}, {0.08f, 0.05f, 0.16f}, 0.110f},
        // 41-50 : lava
        {{0.55f, 0.15f, 0.10f}, {0.95f, 0.45f, 0.15f}, {0.20f, 0.11f, 0.10f},
         {0.25f, 0.13f, 0.11f}, {0.12f, 0.04f, 0.04f}, 0.110f},
};

const Theme &themeFor(int level) {
    int i = (level - 1) / 10;
    i = std::max(0, std::min(4, i));
    return kThemes[i];
}

// ---------------------------------------------------------------- shaders
const char *kVert = R"(#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec3 aColor;
uniform mat4 uVP;
uniform mat4 uModel;
out vec3 vColor;
out vec3 vNormal;
out vec3 vWorld;
void main() {
    vec4 w = uModel * vec4(aPos, 1.0);
    vWorld = w.xyz;
    vNormal = mat3(uModel) * aNormal;
    vColor = aColor;
    gl_Position = uVP * w;
}
)";

const char *kFrag = R"(#version 300 es
precision highp float;
in vec3 vColor;
in vec3 vNormal;
in vec3 vWorld;
uniform vec3 uCam;
uniform vec3 uFogColor;
uniform float uFogDen;
uniform vec3 uTint;
uniform float uEmis;
out vec4 oColor;
void main() {
    vec3 n = normalize(vNormal);
    vec3 L = normalize(vec3(0.45, 0.85, 0.30));
    float diff = max(dot(n, L), 0.0);
    float hemi = 0.5 + 0.5 * n.y;
    vec3 base = vColor * uTint;
    vec3 lit = base * (0.30 + 0.30 * hemi + 0.55 * diff);
    lit = mix(lit, base * 1.25, uEmis);
    float d = length(vWorld - uCam);
    float f = 1.0 - exp(-(d * uFogDen) * (d * uFogDen));
    oColor = vec4(mix(lit, uFogColor, clamp(f, 0.0, 1.0)), 1.0);
}
)";

GLuint compileShader(GLenum type, const char *src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[1024];
        glGetShaderInfoLog(s, sizeof(buf), nullptr, buf);
        LOGE("Shader compile error: %s", buf);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

// ---------------------------------------------------------------- mesh building
// Vertex layout: position(3) normal(3) color(3)
struct MeshBuilder {
    std::vector<float> v;

    void vert(const float *p, const float *n, const float *c) {
        v.insert(v.end(), {p[0], p[1], p[2], n[0], n[1], n[2], c[0], c[1], c[2]});
    }

    void quad(const float a[3], const float b[3], const float c[3], const float d[3],
              const float n[3], const float col[3]) {
        vert(a, n, col);
        vert(b, n, col);
        vert(c, n, col);
        vert(a, n, col);
        vert(c, n, col);
        vert(d, n, col);
    }

    void tri(const float a[3], const float b[3], const float c[3], const float col[3]) {
        mu::V3 A{a[0], a[1], a[2]}, B{b[0], b[1], b[2]}, C{c[0], c[1], c[2]};
        mu::V3 nn = mu::norm(mu::cross(mu::sub(B, A), mu::sub(C, A)));
        float n[3] = {nn.x, nn.y, nn.z};
        vert(a, n, col);
        vert(b, n, col);
        vert(c, n, col);
    }

    // flat horizontal quad at height y
    void floorQuad(float x0, float z0, float x1, float z1, float y, const float col[3]) {
        const float n[3] = {0, 1, 0};
        const float a[3] = {x0, y, z1}, b[3] = {x1, y, z1}, c[3] = {x1, y, z0}, d[3] = {x0, y, z0};
        quad(a, b, c, d, n, col);
    }

    // box without a bottom face
    void box(float x0, float y0, float z0, float x1, float y1, float z1, const float side[3],
             const float top[3]) {
        {
            const float n[3] = {0, 1, 0};
            const float a[3] = {x0, y1, z1}, b[3] = {x1, y1, z1}, c[3] = {x1, y1, z0},
                    d[3] = {x0, y1, z0};
            quad(a, b, c, d, n, top);
        }
        {
            const float n[3] = {0, 0, -1};
            const float a[3] = {x1, y0, z0}, b[3] = {x0, y0, z0}, c[3] = {x0, y1, z0},
                    d[3] = {x1, y1, z0};
            quad(a, b, c, d, n, side);
        }
        {
            const float n[3] = {0, 0, 1};
            const float a[3] = {x0, y0, z1}, b[3] = {x1, y0, z1}, c[3] = {x1, y1, z1},
                    d[3] = {x0, y1, z1};
            quad(a, b, c, d, n, side);
        }
        {
            const float n[3] = {-1, 0, 0};
            const float a[3] = {x0, y0, z0}, b[3] = {x0, y0, z1}, c[3] = {x0, y1, z1},
                    d[3] = {x0, y1, z0};
            quad(a, b, c, d, n, side);
        }
        {
            const float n[3] = {1, 0, 0};
            const float a[3] = {x1, y0, z1}, b[3] = {x1, y0, z0}, c[3] = {x1, y1, z0},
                    d[3] = {x1, y1, z1};
            quad(a, b, c, d, n, side);
        }
    }
};

void uploadMesh(const std::vector<float> &data, GLuint &vao, GLuint &vbo) {
    if (!vao) glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    if (!vbo) glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr) (data.size() * sizeof(float)), data.data(),
                 GL_STATIC_DRAW);
    const GLsizei stride = 9 * sizeof(float);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (const void *) 0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (const void *) (3 * sizeof(float)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, stride, (const void *) (6 * sizeof(float)));
    glBindVertexArray(0);
}

float smooth(float t) {
    t = std::max(0.0f, std::min(1.0f, t));
    return t * t * (3.0f - 2.0f * t);
}

}  // namespace

// ---------------------------------------------------------------- Renderer
bool Renderer::buildProgram() {
    GLuint vs = compileShader(GL_VERTEX_SHADER, kVert);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, kFrag);
    if (!vs || !fs) return false;
    prog_ = glCreateProgram();
    glAttachShader(prog_, vs);
    glAttachShader(prog_, fs);
    glLinkProgram(prog_);
    glDeleteShader(vs);
    glDeleteShader(fs);
    GLint ok = 0;
    glGetProgramiv(prog_, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[1024];
        glGetProgramInfoLog(prog_, sizeof(buf), nullptr, buf);
        LOGE("Program link error: %s", buf);
        prog_ = 0;
        return false;
    }
    uVP_ = glGetUniformLocation(prog_, "uVP");
    uModel_ = glGetUniformLocation(prog_, "uModel");
    uCam_ = glGetUniformLocation(prog_, "uCam");
    uFogColor_ = glGetUniformLocation(prog_, "uFogColor");
    uFogDen_ = glGetUniformLocation(prog_, "uFogDen");
    uTint_ = glGetUniformLocation(prog_, "uTint");
    uEmis_ = glGetUniformLocation(prog_, "uEmis");
    return true;
}

void Renderer::buildGem() {
    // unit octahedron used for the exit crystal and the start marker
    MeshBuilder mb;
    const float white[3] = {1, 1, 1};
    const float T[3] = {0, 1, 0}, B[3] = {0, -1, 0};
    const float X1[3] = {1, 0, 0}, Z1[3] = {0, 0, 1}, X2[3] = {-1, 0, 0}, Z2[3] = {0, 0, -1};
    mb.tri(T, Z1, X1, white);
    mb.tri(T, X2, Z1, white);
    mb.tri(T, Z2, X2, white);
    mb.tri(T, X1, Z2, white);
    mb.tri(B, X1, Z1, white);
    mb.tri(B, Z1, X2, white);
    mb.tri(B, X2, Z2, white);
    mb.tri(B, Z2, X1, white);
    gemVerts_ = (int) (mb.v.size() / 9);
    uploadMesh(mb.v, gemVao_, gemVbo_);
}

void Renderer::rebuildLevelMesh() {
    std::lock_guard<std::mutex> lk(game_.mtx);
    const Theme &th = themeFor(game_.level);
    const int n = game_.size;
    const float S = Game::CELL;
    const float E = n * S;

    MeshBuilder mb;

    // big ground plate under everything
    const float groundCol[3] = {th.floorA[0] * 0.55f, th.floorA[1] * 0.55f, th.floorA[2] * 0.55f};
    mb.floorQuad(-60.0f, -60.0f, E + 60.0f, E + 60.0f, -0.15f, groundCol);

    // checkered floor
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const float *c = ((i + j) & 1) ? th.floorB : th.floorA;
            mb.floorQuad(i * S, j * S, (i + 1) * S, (j + 1) * S, 0.0f, c);
        }
    }

    // start pad (green) and exit pad (red)
    {
        const float green[3] = {0.20f, 0.85f, 0.35f};
        const float red[3] = {0.95f, 0.25f, 0.20f};
        const float inset = 0.25f;
        int sx = game_.startCell % n, sz = game_.startCell / n;
        int ex = game_.exitCell % n, ez = game_.exitCell / n;
        mb.box(sx * S + inset, 0.0f, sz * S + inset, (sx + 1) * S - inset, 0.04f,
               (sz + 1) * S - inset, green, green);
        mb.box(ex * S + inset, 0.0f, ez * S + inset, (ex + 1) * S - inset, 0.04f,
               (ez + 1) * S - inset, red, red);
    }

    // walls
    int idx = 0;
    for (const Rect &w : game_.walls) {
        float shade = 0.93f + 0.07f * (float) ((idx * 7) % 5) / 4.0f;
        ++idx;
        const float side[3] = {th.side[0] * shade, th.side[1] * shade, th.side[2] * shade};
        const float top[3] = {th.top[0] * shade, th.top[1] * shade, th.top[2] * shade};
        mb.box(w.x0, 0.0f, w.z0, w.x1, Game::WALL_H, w.z1, side, top);
    }

    levelVerts_ = (int) (mb.v.size() / 9);
    uploadMesh(mb.v, levelVao_, levelVbo_);
    builtVersion_ = game_.version;
}

void Renderer::onSurfaceCreated() {
    prog_ = 0;
    levelVao_ = levelVbo_ = gemVao_ = gemVbo_ = 0;  // old GL objects died with the context
    levelVerts_ = gemVerts_ = 0;
    builtVersion_ = -1;
    haveLast_ = false;
    if (!buildProgram()) return;
    buildGem();
    glEnable(GL_DEPTH_TEST);
}

void Renderer::onSurfaceChanged(int w, int h) {
    width_ = std::max(1, w);
    height_ = std::max(1, h);
    glViewport(0, 0, width_, height_);
}

void Renderer::onDrawFrame() {
    // ---- timing + game update
    auto now = std::chrono::steady_clock::now();
    float dt = 0.0f;
    if (haveLast_) dt = std::chrono::duration<float>(now - last_).count();
    last_ = now;
    haveLast_ = true;
    dt = std::min(dt, 0.1f);
    timeSec_ += dt;
    game_.update(dt);

    CamState cs = game_.camState();

    if (!prog_ || cs.state == ST_IDLE) {
        glClearColor(0.04f, 0.08f, 0.12f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        return;
    }
    if (cs.version != builtVersion_) rebuildLevelMesh();

    const Theme &th = themeFor(cs.level);
    glViewport(0, 0, width_, height_);
    glClearColor(th.sky[0], th.sky[1], th.sky[2], 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);

    // ---- camera: top-down preview <-> first person
    float b;  // 0 = preview camera, 1 = first-person camera
    if (cs.state == ST_PREVIEW) b = 0.0f;
    else if (cs.state == ST_TRANSITION) b = smooth(cs.transT);
    else b = 1.0f;

    const float E = cs.size * Game::CELL;
    const float cx = E * 0.5f;
    const float aspect = (float) width_ / (float) height_;
    const float fovP = 50.0f * 3.14159265f / 180.0f;
    const float fovF = 70.0f * 3.14159265f / 180.0f;
    // distance so that the whole maze fits on screen
    const float dist = (E * 0.5f * 1.12f) / (std::tan(fovP * 0.5f) * std::min(1.0f, aspect));

    mu::V3 eyeP{cx, dist, cx}, ctrP{cx, 0.0f, cx}, upP{0.0f, 0.0f, -1.0f};
    const float fx = std::sin(cs.yaw), fz = -std::cos(cs.yaw);
    mu::V3 eyeF{cs.px, Game::EYE_H, cs.pz};
    mu::V3 ctrF{cs.px + fx, Game::EYE_H, cs.pz + fz};
    mu::V3 upF{0.0f, 1.0f, 0.0f};

    mu::V3 eye = mu::lerp(eyeP, eyeF, b);
    mu::V3 ctr = mu::lerp(ctrP, ctrF, b);
    mu::V3 up = mu::norm(mu::lerp(upP, upF, b));

    float proj[16], view[16], vp[16];
    mu::perspective(proj, mu::lerpf(fovP, fovF, b), aspect, mu::lerpf(0.5f, 0.05f, b), 200.0f);
    mu::lookAt(view, eye, ctr, up);
    mu::mul(vp, proj, view);

    glUseProgram(prog_);
    glUniformMatrix4fv(uVP_, 1, GL_FALSE, vp);
    glUniform3f(uCam_, eye.x, eye.y, eye.z);
    glUniform3f(uFogColor_, th.sky[0], th.sky[1], th.sky[2]);
    glUniform1f(uFogDen_, th.fog * b);

    // ---- maze
    float ident[16];
    mu::identity(ident);
    glUniformMatrix4fv(uModel_, 1, GL_FALSE, ident);
    glUniform3f(uTint_, 1.0f, 1.0f, 1.0f);
    glUniform1f(uEmis_, 0.0f);
    glBindVertexArray(levelVao_);
    glDrawArrays(GL_TRIANGLES, 0, levelVerts_);

    // ---- crystals (exit = red, start = green while the maze is being shown)
    glBindVertexArray(gemVao_);
    glUniform1f(uEmis_, 1.0f);
    const float bob = std::sin(timeSec_ * 2.2f) * 0.12f;
    const float big = 0.65f - 0.27f * b;
    float m[16];

    mu::model(m, cs.exitX, 0.95f + bob, cs.exitZ, timeSec_ * 1.6f, big * 0.8f, big * 1.2f,
              big * 0.8f);
    glUniformMatrix4fv(uModel_, 1, GL_FALSE, m);
    glUniform3f(uTint_, 1.0f, 0.30f, 0.25f);
    glDrawArrays(GL_TRIANGLES, 0, gemVerts_);

    if (cs.state == ST_PREVIEW || cs.state == ST_TRANSITION) {
        mu::model(m, cs.startX, 0.95f + bob, cs.startZ, -timeSec_ * 1.6f, big * 0.8f, big * 1.2f,
                  big * 0.8f);
        glUniformMatrix4fv(uModel_, 1, GL_FALSE, m);
        glUniform3f(uTint_, 0.30f, 1.0f, 0.40f);
        glDrawArrays(GL_TRIANGLES, 0, gemVerts_);
    }
    glBindVertexArray(0);
}
