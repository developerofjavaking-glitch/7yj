package com.maze.bdcreator

import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay

/**
 * Picks an RGB888 + ES3 config with a 24-bit depth buffer and falls back to 16-bit
 * (then to any ES3 config) so the game never ends on a black screen because a
 * device does not offer the exact config we first asked for.
 */
class DepthConfigChooser : GLSurfaceView.EGLConfigChooser {

    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        for (depth in intArrayOf(24, 16, 0)) {
            val attrs = intArrayOf(
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depth,
                EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
                EGL10.EGL_NONE
            )
            val count = IntArray(1)
            if (!egl.eglChooseConfig(display, attrs, null, 0, count) || count[0] <= 0) continue
            val configs = arrayOfNulls<EGLConfig>(count[0])
            if (!egl.eglChooseConfig(display, attrs, configs, count[0], count)) continue
            val first = configs.firstOrNull { it != null }
            if (first != null) return first
        }
        throw IllegalStateException("No OpenGL ES 3.0 EGL config available")
    }

    private companion object {
        const val EGL_OPENGL_ES3_BIT = 0x40
    }
}
