package com.maze.bdcreator

import android.content.Context

/** Saves unlocked levels and best times. */
object Progress {
    private const val PREFS = "maze_progress"
    const val MAX_LEVEL = 50

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun unlocked(ctx: Context): Int =
        prefs(ctx).getInt("unlocked", 1).coerceIn(1, MAX_LEVEL)

    /** Best time in seconds, or 0f if the level was never completed. */
    fun bestTime(ctx: Context, level: Int): Float = prefs(ctx).getFloat("best_$level", 0f)

    /** Stores a finished level and returns the (possibly new) best time. */
    fun saveWin(ctx: Context, level: Int, time: Float): Float {
        val p = prefs(ctx)
        val best = p.getFloat("best_$level", 0f)
        val newBest = if (best <= 0f || time < best) time else best
        p.edit()
            .putInt("unlocked", maxOf(unlocked(ctx), minOf(MAX_LEVEL, level + 1)))
            .putFloat("best_$level", newBest)
            .apply()
        return newBest
    }
}
