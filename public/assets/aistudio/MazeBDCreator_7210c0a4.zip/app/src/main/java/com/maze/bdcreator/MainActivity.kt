package com.maze.bdcreator

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var btnPlay: Button
    private lateinit var grid: GridLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        btnPlay = findViewById(R.id.btnPlay)
        grid = findViewById(R.id.grid)

        // keep the layout clear of the status bar / navigation bar / camera cutout
        val root = findViewById<View>(R.id.root)
        val pl = root.paddingLeft
        val pt = root.paddingTop
        val pr = root.paddingRight
        val pb = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(pl + bars.left, pt + bars.top, pr + bars.right, pb + bars.bottom)
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun refresh() {
        val unlocked = Progress.unlocked(this)

        btnPlay.text = getString(R.string.continue_level, unlocked)
        btnPlay.setOnClickListener { startLevel(unlocked) }

        grid.removeAllViews()
        for (level in 1..Progress.MAX_LEVEL) {
            val best = Progress.bestTime(this, level)
            val isLocked = level > unlocked

            val b = Button(this)
            b.text = if (best > 0f) {
                String.format(Locale.US, "%d\n%.1fs", level, best)
            } else {
                level.toString()
            }
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (best > 0f) 12f else 17f)
            b.setTextColor(Color.WHITE)
            b.isAllCaps = false
            b.gravity = Gravity.CENTER
            // The default button style forces a large minimum size (88dp wide), which made
            // five columns overflow on narrow phones. Remove it.
            b.minWidth = 0
            b.minimumWidth = 0
            b.minHeight = 0
            b.minimumHeight = 0
            b.setPadding(0, 0, 0, 0)
            b.stateListAnimator = null

            val bg = GradientDrawable()
            bg.cornerRadius = dp(12).toFloat()
            bg.setColor(
                when {
                    isLocked -> Color.parseColor("#455A64")
                    best > 0f -> Color.parseColor("#2E9B4E")
                    else -> Color.parseColor("#1BA6A0")
                }
            )
            b.background = bg
            b.alpha = if (isLocked) 0.45f else 1f
            b.isEnabled = !isLocked
            b.setOnClickListener { startLevel(level) }

            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                height = dp(60)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(b, lp)
        }
    }

    private fun startLevel(level: Int) {
        startActivity(
            Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_LEVEL, level)
        )
    }
}
