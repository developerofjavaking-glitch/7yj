package com.maze.bdcreator

import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.Locale
import kotlin.math.ceil

class GameActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_LEVEL = "level"
    }

    private lateinit var glView: GLSurfaceView
    private lateinit var controls: ControlsView
    private lateinit var tvLevel: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvBanner: TextView
    private lateinit var tvHint: TextView
    private lateinit var btnSkip: Button
    private lateinit var btnPause: Button
    private lateinit var panel: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var panelInfo: TextView
    private lateinit var btnPrimary: Button
    private lateinit var btnRetry: Button
    private lateinit var btnMenu: Button

    private val handler = Handler(Looper.getMainLooper())
    private var level = 1
    private var winHandled = false

    private val tick = object : Runnable {
        override fun run() {
            updateHud()
            handler.postDelayed(this, 80)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        setContentView(R.layout.activity_game)

        glView = findViewById(R.id.glView)
        controls = findViewById(R.id.controls)
        tvLevel = findViewById(R.id.tvLevel)
        tvTime = findViewById(R.id.tvTime)
        tvBanner = findViewById(R.id.tvBanner)
        tvHint = findViewById(R.id.tvHint)
        btnSkip = findViewById(R.id.btnSkip)
        btnPause = findViewById(R.id.btnPause)
        panel = findViewById(R.id.panel)
        panelTitle = findViewById(R.id.panelTitle)
        panelInfo = findViewById(R.id.panelInfo)
        btnPrimary = findViewById(R.id.btnPrimary)
        btnRetry = findViewById(R.id.btnRetry)
        btnMenu = findViewById(R.id.btnMenu)

        glView.setEGLContextClientVersion(3)
        glView.setEGLConfigChooser(DepthConfigChooser())
        glView.setRenderer(GameRenderer())
        glView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        level = intent.getIntExtra(EXTRA_LEVEL, 1).coerceIn(1, Progress.MAX_LEVEL)
        beginLevel(level)

        btnPause.setOnClickListener { showPause() }
        btnSkip.setOnClickListener { NativeBridge.nativeSkipPreview() }
        btnRetry.setOnClickListener { beginLevel(level) }
        btnMenu.setOnClickListener { finish() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (panel.visibility == View.VISIBLE) {
                    if (!winHandled) resumeGame() else finish()
                } else {
                    showPause()
                }
            }
        })
    }

    private fun beginLevel(lv: Int) {
        level = lv
        winHandled = false
        panel.visibility = View.GONE
        controls.cancelAll()
        NativeBridge.nativeStartLevel(lv)
        tvLevel.text = getString(R.string.level_fmt, lv)
        tvTime.text = "0.0"
    }

    private fun updateHud() {
        when (NativeBridge.nativeGetState()) {
            NativeBridge.ST_PREVIEW -> {
                val left = ceil(NativeBridge.nativeGetPreviewLeft()).toInt().coerceAtLeast(1)
                tvBanner.visibility = View.VISIBLE
                tvBanner.text = getString(R.string.memorize, left)
                btnSkip.visibility = View.VISIBLE
                tvHint.visibility = View.VISIBLE
                tvTime.text = "0.0"
            }

            NativeBridge.ST_TRANSITION -> {
                tvBanner.visibility = View.VISIBLE
                tvBanner.text = getString(R.string.go)
                btnSkip.visibility = View.GONE
                tvHint.visibility = View.GONE
            }

            NativeBridge.ST_PLAY -> {
                tvBanner.visibility = View.GONE
                btnSkip.visibility = View.GONE
                tvHint.visibility = View.GONE
                tvTime.text = String.format(Locale.US, "%.1f", NativeBridge.nativeGetElapsed())
            }

            NativeBridge.ST_WON -> {
                tvBanner.visibility = View.GONE
                if (!winHandled) onWin()
            }
        }
    }

    private fun onWin() {
        winHandled = true
        val time = NativeBridge.nativeGetElapsed()
        val best = Progress.saveWin(this, level, time)
        tvTime.text = String.format(Locale.US, "%.1f", time)

        val info = getString(R.string.time_fmt, time) + "\n" + getString(R.string.best_fmt, best)
        if (level >= Progress.MAX_LEVEL) {
            showPanel(getString(R.string.all_done), info, null) {}
        } else {
            showPanel(
                getString(R.string.level_complete, level),
                info,
                getString(R.string.next_level)
            ) { beginLevel(level + 1) }
        }
    }

    private fun showPanel(title: String, info: String, primaryLabel: String?, primary: () -> Unit) {
        controls.cancelAll()
        panelTitle.text = title
        panelInfo.text = info
        panelInfo.visibility = if (info.isEmpty()) View.GONE else View.VISIBLE
        if (primaryLabel != null) {
            btnPrimary.visibility = View.VISIBLE
            btnPrimary.text = primaryLabel
            btnPrimary.setOnClickListener { primary() }
        } else {
            btnPrimary.visibility = View.GONE
        }
        panel.visibility = View.VISIBLE
    }

    private fun showPause() {
        if (panel.visibility == View.VISIBLE) return
        NativeBridge.nativeSetPaused(true)
        showPanel(getString(R.string.paused), "", getString(R.string.resume)) { resumeGame() }
    }

    private fun resumeGame() {
        panel.visibility = View.GONE
        NativeBridge.nativeSetPaused(false)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        glView.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        glView.onPause()
        if (!winHandled) showPause()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }
}
