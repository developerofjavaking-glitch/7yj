package com.maze.bdcreator

/** JNI bridge to the C/C++ game engine (libmazebd.so). */
object NativeBridge {
    init {
        System.loadLibrary("mazebd")
    }

    // GL thread
    @JvmStatic external fun nativeSurfaceCreated()
    @JvmStatic external fun nativeSurfaceChanged(width: Int, height: Int)
    @JvmStatic external fun nativeDrawFrame()

    // UI thread
    @JvmStatic external fun nativeStartLevel(level: Int)
    @JvmStatic external fun nativeSetMove(x: Float, y: Float)
    @JvmStatic external fun nativeAddLook(dyaw: Float)
    @JvmStatic external fun nativeSkipPreview()
    @JvmStatic external fun nativeSetPaused(paused: Boolean)
    @JvmStatic external fun nativeGetState(): Int
    @JvmStatic external fun nativeGetPreviewLeft(): Float
    @JvmStatic external fun nativeGetElapsed(): Float
    @JvmStatic external fun nativeGetLevel(): Int

    // Must match enum GameState in game.h
    const val ST_IDLE = 0
    const val ST_PREVIEW = 1
    const val ST_TRANSITION = 2
    const val ST_PLAY = 3
    const val ST_WON = 4
}
