package com.maze.bdcreator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Transparent overlay with touch controls:
 *  - left half : floating virtual joystick (move)
 *  - right half: drag to look around
 */
class ControlsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val baseRadius = 64f * density
    private val knobRadius = 28f * density

    private var joyId = -1
    private var lookId = -1
    private var joyCx = 0f
    private var joyCy = 0f
    private var joyX = 0f
    private var joyY = 0f
    private var lastLookX = 0f

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 255, 255, 255)
        style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i)
                val y = e.getY(i)
                if (x < width * 0.5f) {
                    if (joyId == -1) {
                        joyId = id
                        joyCx = x; joyCy = y
                        joyX = x; joyY = y
                        sendMove()
                    }
                } else if (lookId == -1) {
                    lookId = id
                    lastLookX = x
                }
            }

            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    if (id == joyId) {
                        joyX = e.getX(i)
                        joyY = e.getY(i)
                        sendMove()
                    } else if (id == lookId) {
                        val x = e.getX(i)
                        NativeBridge.nativeAddLook((x - lastLookX) * 0.006f)
                        lastLookX = x
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                if (id == joyId) {
                    joyId = -1
                    NativeBridge.nativeSetMove(0f, 0f)
                } else if (id == lookId) {
                    lookId = -1
                }
            }

            MotionEvent.ACTION_CANCEL -> cancelAll()
        }
        invalidate()
        return true
    }

    /** Releases all touches (used when a menu/panel is shown). */
    fun cancelAll() {
        joyId = -1
        lookId = -1
        NativeBridge.nativeSetMove(0f, 0f)
        invalidate()
    }

    private fun sendMove() {
        var dx = joyX - joyCx
        var dy = joyY - joyCy
        val len = hypot(dx, dy)
        if (len > baseRadius) {
            dx = dx / len * baseRadius
            dy = dy / len * baseRadius
            joyX = joyCx + dx
            joyY = joyCy + dy
        }
        var nx = dx / baseRadius
        var ny = dy / baseRadius
        if (hypot(nx, ny) < 0.12f) { // dead zone
            nx = 0f; ny = 0f
        }
        NativeBridge.nativeSetMove(nx, -ny) // screen up = forward
    }

    override fun onDraw(canvas: Canvas) {
        if (joyId != -1) {
            canvas.drawCircle(joyCx, joyCy, baseRadius, basePaint)
            canvas.drawCircle(joyCx, joyCy, baseRadius, ringPaint)
            canvas.drawCircle(joyX, joyY, knobRadius, knobPaint)
        }
    }
}
